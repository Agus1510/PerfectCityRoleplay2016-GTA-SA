<?php
// phpBB 3.1.x auto-generated configuration file
// Do not change anything in this file!
$dbms = 'phpbb\\db\\driver\\mysqli';
$dbhost = 'localhost';
$dbport = '';
$dbname = 'plati354_foro';
$dbuser = 'plati354_foro';
$dbpasswd = 'a�undrel42';
$table_prefix = 'tabla_';
$phpbb_adm_relative_path = 'adm/';
$acm_type = 'phpbb\\cache\\driver\\file';

@define('PHPBB_INSTALLED', true);
// @define('PHPBB_DISPLAY_LOAD_TIME', true);
// @define('DEBUG', true);
// @define('DEBUG_CONTAINER', true);
