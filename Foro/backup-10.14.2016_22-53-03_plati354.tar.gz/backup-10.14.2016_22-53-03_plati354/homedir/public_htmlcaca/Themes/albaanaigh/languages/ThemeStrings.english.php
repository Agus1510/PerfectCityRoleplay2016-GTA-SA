<?php
// Version: 2.0.2; ThemeStrings

/* 	This theme is licensed under the BSD license
    SMFHacks.com - Modifications and Products for SMF forum software
    
    If you like this theme contact us at http://www.smfhacks.com for copyright removal donation
*/

$txt['on_image'] = 'New Post Indicator <br /><span class="smalltext">Just like the header url in default theme place the url to your image here, please use the full url.  This will change the on.png image</span>';
$txt['off_image'] = 'No New Post Indicator<br /><span class="smalltext">Just like the header in default theme url place the url to your image here, please use the full url. This will change the off.png image.</span>';
$txt['redirect_image'] = 'Redirect Indicator<br /><span class="smalltext">Just like the header url in default theme place the url to your image here, please use the full url. This will change the redirect.png image.</span>';
$txt['new_some_image'] = 'New Some Indicator<br /><span class="smalltext">Just like the header url in default theme place the url to your image here, please use the full url.  This will change the new_some.png image.</span>';
$txt['new_none_image'] = 'New None Indicator<br /><span class="smalltext">Just like the header url place the url to your image here, please use the full url. This will change the new_none.png image.</span>';
$txt['new_redirect_image'] = 'New Redirect Indicator<br /><span class="smalltext">Just like the header url in default theme place the url to your image here, please use the full url. This will change the new_redirect.png image.</span>';
$txt['on2_image'] = 'New Child Post Indicator<br /><span class="smalltext">Just like the header url in default theme place the url to your image here, please use the full url.  This will change the on2.png image.</span>';

$txt['advert_desc'] = 'Place your advert code here (BBC and HTML)';
$txt['advert'] = 'Advert';
$txt['advert_control'] = 'Turn on the Upper Advert Feature';
$txt['advert_control_desc'] = '<b>Please note:</b> the feature needs to be turned on for it to work';
$txt['advert_desc'] = 'Place your advert code here (BBC and HTML)';

$txt['advert_desca'] = 'Place your advert code here (BBC and HTML)';
$txt['adverta'] = 'Advert';
$txt['advert_controla'] = 'Turn on the Footer Advert Feature';
$txt['advert_control_desca'] = '<b>Please note:</b> the feature needs to be turned on for it to work';

$txt['advert_header'] = 'Why Not Visit:';

$txt['cc_desc'] = 'Place your custom copyright here (BBC and HTML)';
$txt['cc'] = 'Custom Copyright';
$txt['cc_control'] = 'Turn on the Custom Copyright Feature';
$txt['cc_control_desc'] = '<b>Please note:</b> the feature needs to be turned on for it to work';

$txt['t_terms'] = "Terms of Services";
$txt['t_terms_admin'] = "Link to your <strong>Terms of Services</strong> page";
$txt['t_policy'] = "Privacy Policy";
$txt['t_policy_admin'] = "Link to your <strong>Privacy Policy</strong> page";
$txt['t_contact'] = "Contact us";
$txt['t_contact_admin'] = "Link to your <strong>Contact us</strong> page";

$txt['hello_member_alba'] = 'F&agrave;ilte';
?>