<?php
// Version: 2.0.2; Settings

/* 	This theme is licensed under the BSD license
    SMFHacks.com - Modifications and Products for SMF forum software
    
    If you like this theme contact us at http://www.smfhacks.com for copyright removal donation
*/
global $settings;

$txt['theme_thumbnail_href'] = $settings['images_url'] . '/thumbnail.png';
$txt['theme_description'] = 'Alba An Aigh.<br />Author: SMFHacks.com<br /> <a href="">SMFHacks.com - Mods and Products for SMF</a>.';
?>